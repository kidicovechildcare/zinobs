import Link from 'next/link';
import { Hammer, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-neutral-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Hammer className="h-6 w-6 text-amber-600" />
              <span className="text-xl font-bold text-white">Zino Building</span>
            </div>
            <p className="text-sm">
              Crafting exceptional woodwork and custom cabinetry across Canada since 2010.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="hover:text-amber-600 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/projects" className="hover:text-amber-600 transition-colors">
                  Our Projects
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-amber-600 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>Kitchen Cabinets</li>
              <li>Built-in Closets</li>
              <li>Custom Furniture</li>
              <li>Office Millwork</li>
              <li>Residential Projects</li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-amber-600" />
                <span>(+1) 604-300-1011</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-amber-600" />
                <span>zinobs@gmail.com</span>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin className="h-4 w-4 text-amber-600 mt-0.5" />
                <span>987 Cross Creek Road, West Vancouver, BC, Canada</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-neutral-800 mt-8 pt-8 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} Zino Building Solutions. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
