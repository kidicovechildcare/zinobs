/*
  # Create Contact Submissions Table

  1. New Tables
    - `contact_submissions`
      - `id` (uuid, primary key) - Unique identifier
      - `name` (text) - Contact name
      - `email` (text) - Contact email
      - `phone` (text) - Contact phone number
      - `subject` (text) - Message subject
      - `message` (text) - Full message content
      - `project_type` (text) - Type of project interested in
      - `created_at` (timestamptz) - Submission timestamp
  
  2. Security
    - Enable RLS on `contact_submissions` table
    - Add policy for authenticated insert only
    - No public read access (admin only)
*/

CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  subject text NOT NULL,
  message text NOT NULL,
  project_type text DEFAULT 'General Inquiry',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit contact form"
  ON contact_submissions
  FOR INSERT
  WITH CHECK (true);
