import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, CheckCircle, Hammer, Home, Building2, Lightbulb } from 'lucide-react';
import path from 'path';
import fs from 'fs/promises';

export default async function HomePage() {
  const dirPath = path.join(process.cwd(), 'public', 'zinoiMAGES')
  let imageFiles: string[] = []
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true })
    imageFiles = entries
      .filter((e) => e.isFile())
      .map((e) => e.name)
      .filter((n) => /\.(jpe?g|png|webp|gif)$/i.test(n))
  } catch {
    imageFiles = []
  }

  const toSrc = (name?: string) => (name ? `/zinoiMAGES/${encodeURIComponent(name)}` : '')

  const heroImage = toSrc(imageFiles[0])
  const secondaryImage = toSrc(imageFiles[1])
  const services = [
    {
      icon: Home,
      title: 'Kitchen Cabinets',
      description: 'Custom-designed kitchen cabinetry that combines functionality with stunning aesthetics.',
    },
    {
      icon: Building2,
      title: 'Built-in Closets',
      description: 'Maximize your storage space with beautifully crafted built-in closet systems.',
    },
    {
      icon: Hammer,
      title: 'Custom Furniture',
      description: 'Unique, handcrafted furniture pieces tailored to your specific needs and style.',
    },
    {
      icon: Lightbulb,
      title: 'Office Millwork',
      description: 'Professional office woodwork that enhances productivity and creates lasting impressions.',
    },
  ];

  const features = [
    'Premium quality materials',
    'Expert craftsmanship',
    'Custom designs',
    'On-time delivery',
    'Competitive pricing',
    'Warranty included',
  ];

  const projects = imageFiles.slice(2, 10).map((file, idx) => ({
    title: `Project ${idx + 1}`,
    category: 'Portfolio',
    image: toSrc(file),
  }))

  return (
    <div className="pt-20">
      <section className="relative bg-gradient-to-br from-neutral-900 via-neutral-800 to-amber-900 text-white py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                Crafting Excellence in Wood
              </h1>
              <p className="text-xl text-neutral-200">
                Transform your space with custom woodworking and cabinetry designed for Canadian homes and businesses.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-amber-600 hover:bg-amber-700 text-lg">
                  <Link href="/contact">
                    Get Started <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="text-lg border-white bg-transparent text-white hover:bg-white hover:text-neutral-900">
                  <Link href="/projects">View Projects</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
              <img
                src={heroImage}
                alt="Project photo"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
              Our Services
            </h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              From concept to completion, we deliver exceptional woodworking solutions tailored to your vision.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="border-neutral-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                    <service.icon className="h-6 w-6 text-amber-700" />
                  </div>
                  <h3 className="text-xl font-semibold text-neutral-900">{service.title}</h3>
                  <p className="text-neutral-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
              <img
                src={secondaryImage || heroImage}
                alt="Project detail"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-neutral-900">
                Why Choose Zino Building Solutions?
              </h2>
              <p className="text-lg text-neutral-600">
                With over a decade of experience serving clients across Canada, we bring unmatched expertise and dedication to every project.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                    <span className="text-neutral-700">{feature}</span>
                  </div>
                ))}
              </div>
              <Button asChild className="bg-amber-700 hover:bg-amber-800">
                <Link href="/about">Learn More About Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
              Featured Projects
            </h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Explore our portfolio of completed projects showcasing our commitment to quality and design excellence.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {projects.map((project, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-72 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                  <p className="text-amber-400 text-sm font-medium">{project.category}</p>
                  <h3 className="text-white text-lg font-semibold">{project.title}</h3>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild size="lg" className="bg-amber-700 hover:bg-amber-800">
              <Link href="/projects">
                View All Projects <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-20 bg-amber-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Space?
          </h2>
          <p className="text-xl text-amber-100 mb-8">
            Let's discuss your project and bring your vision to life with our expert craftsmanship.
          </p>
          <Button asChild size="lg" className="bg-white text-amber-700 hover:bg-neutral-100">
            <Link href="/contact">
              Get Your Free Quote <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
