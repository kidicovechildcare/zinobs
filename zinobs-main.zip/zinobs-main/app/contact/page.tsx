'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    projectType: 'General Inquiry',
    message: '',
    kitchenSize: '',
    kitchenShape: '',
    hasIsland: '',
    numCabinets: '',
    numDrawers: '',
    numPanels: '',
    numFillers: '',
    location: '',
    workType: '',
    customerType: '',
    planLink: '',
    additionalAreas: [] as string[],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const details: string[] = []
      if (formData.kitchenSize) details.push(`Kitchen size: ${formData.kitchenSize}`)
      if (formData.kitchenShape) details.push(`Kitchen shape: ${formData.kitchenShape}`)
      if (formData.hasIsland) details.push(`Island: ${formData.hasIsland}`)
      const counts = [
        formData.numCabinets && `cabinets ${formData.numCabinets}`,
        formData.numDrawers && `drawers ${formData.numDrawers}`,
        formData.numPanels && `panels ${formData.numPanels}`,
        formData.numFillers && `fillers ${formData.numFillers}`,
      ].filter(Boolean)
      if (counts.length) details.push(`Quantities: ${counts.join(', ')}`)
      if (formData.location) details.push(`Location: ${formData.location}`)
      if (formData.workType) details.push(`Work type: ${formData.workType}`)
      if (formData.customerType) details.push(`Customer type: ${formData.customerType}`)
      if (formData.additionalAreas.length) details.push(`Additional areas: ${formData.additionalAreas.join(', ')}`)
      if (formData.planLink) details.push(`Plan link: ${formData.planLink}`)

      const combinedMessage = details.length
        ? `${formData.message}\n\nProject Details:\n- ${details.join('\n- ')}`
        : formData.message

      if (!supabase) {
        throw new Error('Supabase is not configured');
      }

      const { error } = await supabase
        .from('contact_submissions')
        .insert([
          {
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            subject: formData.subject,
            project_type: formData.projectType,
            message: combinedMessage,
          },
        ]);

      if (error) throw error;

      setSubmitStatus('success');
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        projectType: 'General Inquiry',
        message: '',
        kitchenSize: '',
        kitchenShape: '',
        hasIsland: '',
        numCabinets: '',
        numDrawers: '',
        numPanels: '',
        numFillers: '',
        location: '',
        workType: '',
        customerType: '',
        planLink: '',
        additionalAreas: [],
      });
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="pt-20">
      <section className="relative bg-gradient-to-br from-neutral-900 to-neutral-800 text-white py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Get in Touch</h1>
          <p className="text-xl text-neutral-200 max-w-3xl mx-auto">
            Ready to transform your space? Contact us for a free consultation and quote.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="border-neutral-200">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6 text-amber-700" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Phone</h3>
                <p className="text-neutral-600">604 300 1011</p>
                <p className="text-sm text-neutral-500 mt-1">Mon-Fri 8am-6pm EST</p>
              </CardContent>
            </Card>

            <Card className="border-neutral-200">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6 text-amber-700" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Email</h3>
                <p className="text-neutral-600">zinobs@gmail.com</p>
                <p className="text-sm text-neutral-500 mt-1">We reply within 24 hours</p>
              </CardContent>
            </Card>

            <Card className="border-neutral-200">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6 text-amber-700" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">Location</h3>
                <p className="text-neutral-600">987 Cross Creek Road, West Vancouver, BC, Canada</p>
                <p className="text-sm text-neutral-500 mt-1">Serving all of Canada</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 mb-6">Send Us a Message</h2>
              <p className="text-lg text-neutral-600 mb-8">
                Fill out the form below and our team will get back to you as soon as possible.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    required
                    placeholder="John Smith"
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    required
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="+1 (416) 555-0123"
                  />
                </div>

                <div>
                  <Label htmlFor="projectType">Project Type *</Label>
                  <Select value={formData.projectType} onValueChange={(value) => handleChange('projectType', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="General Inquiry">General Inquiry</SelectItem>
                      <SelectItem value="Kitchen Cabinets">Kitchen Cabinets</SelectItem>
                      <SelectItem value="Built-in Closets">Built-in Closets</SelectItem>
                      <SelectItem value="Custom Furniture">Custom Furniture</SelectItem>
                      <SelectItem value="Office Millwork">Office Millwork</SelectItem>
                      <SelectItem value="Commercial Project">Commercial Project</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="kitchenSize">Kitchen size (feet & inches)</Label>
                    <Input
                      id="kitchenSize"
                      value={formData.kitchenSize}
                      onChange={(e) => handleChange('kitchenSize', e.target.value)}
                      placeholder={`e.g. 12' 6" x 10' 0"`}
                    />
                  </div>
                  <div>
                    <Label>Kitchen shape</Label>
                    <Select value={formData.kitchenShape} onValueChange={(v) => handleChange('kitchenShape', v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select shape" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L shape">L shape</SelectItem>
                        <SelectItem value="U shape">U shape</SelectItem>
                        <SelectItem value="Straight">Straight</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Island</Label>
                    <Select value={formData.hasIsland} onValueChange={(v) => handleChange('hasIsland', v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Has island?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Yes">Yes</SelectItem>
                        <SelectItem value="No">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="numCabinets">Cabinets</Label>
                    <Input id="numCabinets" type="number" min="0" value={formData.numCabinets} onChange={(e) => handleChange('numCabinets', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="numDrawers">Drawers</Label>
                    <Input id="numDrawers" type="number" min="0" value={formData.numDrawers} onChange={(e) => handleChange('numDrawers', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="numPanels">Panels</Label>
                    <Input id="numPanels" type="number" min="0" value={formData.numPanels} onChange={(e) => handleChange('numPanels', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="numFillers">Fillers</Label>
                    <Input id="numFillers" type="number" min="0" value={formData.numFillers} onChange={(e) => handleChange('numFillers', e.target.value)} />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" value={formData.location} onChange={(e) => handleChange('location', e.target.value)} placeholder="City / Area" />
                  </div>
                  <div>
                    <Label>Work type</Label>
                    <Select value={formData.workType} onValueChange={(v) => handleChange('workType', v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select work type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Residential">Residential</SelectItem>
                        <SelectItem value="Commercial">Commercial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Customer type</Label>
                    <Select value={formData.customerType} onValueChange={(v) => handleChange('customerType', v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select customer type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Consumer">Consumer</SelectItem>
                        <SelectItem value="Construction/Contractor">Construction / Contractor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label>Additional areas</Label>
                  <div className="grid md:grid-cols-2 gap-3 mt-2">
                    {[
                      'Closet shelving',
                      'Laundry room cabinets',
                      'Bathroom vanities',
                      'Toilet partitions (commercial)',
                    ].map((label) => {
                      const checked = formData.additionalAreas.includes(label)
                      return (
                        <label key={label} className="flex items-center gap-2 text-neutral-700">
                          <Checkbox
                            checked={checked}
                            onCheckedChange={(val) => {
                              const isChecked = Boolean(val)
                              if (isChecked) handleChange('additionalAreas', [...formData.additionalAreas, label])
                              else handleChange('additionalAreas', formData.additionalAreas.filter((x) => x !== label))
                            }}
                          />
                          <span>{label}</span>
                        </label>
                      )
                    })}
                  </div>
                </div>

                <div>
                  <Label htmlFor="planLink">Floor plan link (optional)</Label>
                  <Input id="planLink" value={formData.planLink} onChange={(e) => handleChange('planLink', e.target.value)} placeholder="URL to your plan (Drive, Dropbox...)" />
                </div>

                <div>
                  <Label htmlFor="subject">Subject *</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => handleChange('subject', e.target.value)}
                    required
                    placeholder="Kitchen renovation quote"
                  />
                </div>

                <div>
                  <Label htmlFor="message">Message *</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleChange('message', e.target.value)}
                    required
                    rows={6}
                    placeholder="Tell us about your project..."
                  />
                </div>

                {submitStatus === 'success' && (
                  <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded">
                    Thank you for your message! We'll get back to you within 24 hours.
                  </div>
                )}

                {submitStatus === 'error' && (
                  <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded">
                    Sorry, there was an error submitting your message. Please try again or contact us directly.
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-amber-700 hover:bg-amber-800"
                  size="lg"
                >
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </Button>
              </form>
            </div>

            <div className="space-y-8">
              <Card className="border-neutral-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-amber-700" />
                    Business Hours
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Monday - Friday</span>
                    <span className="font-medium">8:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Saturday</span>
                    <span className="font-medium">9:00 AM - 3:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600">Sunday</span>
                    <span className="font-medium">Closed</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-neutral-200 bg-amber-50">
                <CardHeader>
                  <CardTitle>Why Choose Zino Building Solutions?</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-neutral-700">
                    <li className="flex items-start">
                      <span className="text-amber-700 mr-2">✓</span>
                      <span>Free in-home consultations and measurements</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-700 mr-2">✓</span>
                      <span>3D design renderings before production</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-700 mr-2">✓</span>
                      <span>Premium materials and expert craftsmanship</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-700 mr-2">✓</span>
                      <span>Transparent pricing with no hidden fees</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-700 mr-2">✓</span>
                      <span>10-year warranty on all workmanship</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <div className="relative h-64 rounded-lg overflow-hidden shadow-lg">
                <img
                  src={'/zinoiMAGES/' + encodeURIComponent('WhatsApp Image 2025-11-04 at 13.36.16.jpeg')}
                  alt="Workshop"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
              Service Areas
            </h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              We proudly serve clients throughout Ontario and across Canada.
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-neutral-900">Greater Toronto Area</h3>
              <p className="text-sm text-neutral-600 mt-2">Toronto, Mississauga, Brampton, Markham</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-neutral-900">York Region</h3>
              <p className="text-sm text-neutral-600 mt-2">Vaughan, Richmond Hill, Aurora</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-neutral-900">Durham Region</h3>
              <p className="text-sm text-neutral-600 mt-2">Oshawa, Whitby, Ajax, Pickering</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-neutral-900">Beyond</h3>
              <p className="text-sm text-neutral-600 mt-2">Ottawa, Hamilton, and more</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
