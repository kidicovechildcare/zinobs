import path from 'path'
import fs from 'fs/promises'
import ProjectsClient from './ProjectsClient'

export default async function ProjectsPage() {
  const dirPath = path.join(process.cwd(), 'public', 'zinoiMAGES')
  let gallery: string[] = []
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true })
    gallery = entries
      .filter((e) => e.isFile())
      .map((e) => e.name)
      .filter((n) => /\.(jpe?g|png|webp|gif)$/i.test(n))
  } catch {
    gallery = []
  }
  return <ProjectsClient gallery={gallery} />
}


