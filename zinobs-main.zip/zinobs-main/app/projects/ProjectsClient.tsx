'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import clsx from 'clsx';

type Props = {
  gallery: string[];
};

type ImageWithLoaderProps = {
  src: string;
  alt: string;
  imgClassName?: string;
  containerClassName?: string;
};

function ImageWithLoader({ src, alt, imgClassName, containerClassName }: ImageWithLoaderProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  return (
    <div className={clsx('relative w-full h-full', containerClassName)}>
      {!loaded && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-neutral-100 animate-pulse">
          <div className="h-6 w-6 border-2 border-neutral-300 border-t-amber-600 rounded-full animate-spin" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        onError={() => {
          setError(true);
          setLoaded(true);
        }}
        className={clsx('w-full h-full object-cover', imgClassName, loaded ? 'opacity-100' : 'opacity-0')}
      />
      {error && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-neutral-200 text-neutral-600 text-xs">
          Image unavailable
        </div>
      )}
    </div>
  );
}

export default function ProjectsClient({ gallery }: Props) {
  const [filter, setFilter] = useState('All');

  const categories = ['All', 'Kitchen', 'Closet', 'Office', 'Living Room', 'Commercial'];

  const baseProjectsMeta = [
    {
      id: 1,
      title: 'Modern Kitchen Renovation',
      category: 'Kitchen',
      description: 'Complete kitchen transformation with custom oak cabinets and quartz countertops.',
    },
    {
      id: 2,
      title: 'Luxury Walk-in Closet',
      category: 'Closet',
      description: 'Custom-designed walk-in closet with LED lighting and premium storage solutions.',
    },
    {
      id: 3,
      title: 'Executive Office Design',
      category: 'Office',
      description: 'Sophisticated mahogany office with built-in bookshelves and desk.',
    },
    {
      id: 4,
      title: 'Custom Entertainment Unit',
      category: 'Living Room',
      description: 'Wall-mounted entertainment center with integrated storage and cable management.',
    },
    {
      id: 5,
      title: 'Contemporary Kitchen Island',
      category: 'Kitchen',
      description: 'Stunning waterfall-edge kitchen island with bar seating and wine storage.',
    },
    {
      id: 6,
      title: 'Corporate Conference Room',
      category: 'Commercial',
      description: 'Professional conference room with custom table and wall paneling.',
    },
    {
      id: 7,
      title: 'Master Bedroom Wardrobe',
      category: 'Closet',
      description: 'Floor-to-ceiling wardrobe system with integrated lighting and mirrors.',
    },
    {
      id: 8,
      title: 'Rustic Farmhouse Kitchen',
      category: 'Kitchen',
      description: 'Charming farmhouse-style kitchen with reclaimed wood accents and vintage hardware.',
    },
    {
      id: 9,
      title: 'Home Library Design',
      category: 'Living Room',
      description: 'Classic home library with floor-to-ceiling bookshelves and reading nook.',
    },
    {
      id: 10,
      title: 'Boutique Retail Fixtures',
      category: 'Commercial',
      description: 'Custom display fixtures and checkout counter for luxury boutique.',
    },
    {
      id: 11,
      title: 'Contemporary Home Office',
      category: 'Office',
      description: 'Minimalist home office with custom desk and storage solutions.',
    },
    {
      id: 12,
      title: 'Villa Master Suite',
      category: 'Closet',
      description: 'Luxurious master suite closet with island and chandelier lighting.',
    },
  ];

  const toLocal = (idx: number) => {
    const safeLen = Math.max(gallery.length, 1);
    const name = gallery[(idx % safeLen + safeLen) % safeLen];
    return name ? `/zinoiMAGES/${encodeURIComponent(name)}` : '';
  };

  const projects = baseProjectsMeta.map((meta, idx) => ({
    ...meta,
    image: toLocal(idx),
    gallery: [toLocal(idx), toLocal(idx + 1), toLocal(idx + 2)],
  }));

  const filteredProjects = filter === 'All'
    ? projects
    : projects.filter(p => p.category === filter);

  return (
    <div className="pt-20">
      <section className="relative bg-gradient-to-br from-neutral-900 to-neutral-800 text-white py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Projects</h1>
          <p className="text-xl text-neutral-200 max-w-3xl mx-auto">
            Explore our portfolio of custom woodworking and cabinetry projects completed across Canada.
          </p>
        </div>
      </section>

      <section className="py-12 bg-white border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <Button
                key={category}
                variant={filter === category ? 'default' : 'outline'}
                onClick={() => setFilter(category)}
                className={filter === category ? 'bg-amber-700 hover:bg-amber-800' : ''}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div key={project.id} className="group bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all">
                <div className="relative h-64 overflow-hidden">
                  <ImageWithLoader
                    src={project.image}
                    alt={project.title}
                    imgClassName="group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-amber-700 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {project.category}
                  </div>
                </div>
                <div className="p-6 space-y-3">
                  <h3 className="text-xl font-semibold text-neutral-900 group-hover:text-amber-700 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-neutral-600">{project.description}</p>
                  <div className="flex gap-2 pt-2">
                    {project.gallery.slice(1, 4).map((img, idx) => (
                      <div key={idx} className="w-16 h-16 rounded overflow-hidden">
                        <ImageWithLoader src={img} alt="" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-20">
              <p className="text-xl text-neutral-600">No projects found in this category.</p>
            </div>
          )}
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">Project Gallery</h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">A selection of our completed works.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {gallery.map((name) => (
              <div key={name} className="relative overflow-hidden rounded-lg border border-neutral-200">
                <ImageWithLoader
                  src={`/zinoiMAGES/${encodeURIComponent(name)}`}
                  alt={name}
                  containerClassName="h-48"
                  imgClassName="hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
          {gallery.length === 0 && (
            <div className="text-center py-10 text-neutral-500">No images available.</div>
          )}
        </div>
      </section>

      <section className="py-20 bg-amber-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Let's Create Something Beautiful Together
          </h2>
          <p className="text-xl text-amber-100 mb-8">
            Ready to start your custom woodworking project? Get in touch for a consultation.
          </p>
          <Button asChild size="lg" className="bg-white text-amber-700 hover:bg-neutral-100">
            <a href="/contact">Contact Us Today</a>
          </Button>
        </div>
      </section>
    </div>
  );
}


