import Link from 'next/link';
import { notFound } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { Calendar, User, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const revalidate = 60;
export const dynamicParams = false;

export async function generateStaticParams() {
  // For static export, do not pre-render dynamic blog pages
  return [];
}

async function getBlogPost(slug: string) {
  if (!supabase) return null;
  const { data, error } = await supabase
    .from('blog_posts')
    .select('*')
    .eq('slug', slug)
    .maybeSingle();

  if (error) {
    console.error('Error fetching blog post:', error);
    return null;
  }

  return data;
}

async function getRecentPosts(currentSlug: string) {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('blog_posts')
    .select('id, title, slug, image_url, category')
    .neq('slug', currentSlug)
    .order('published_at', { ascending: false })
    .limit(3);

  if (error) {
    console.error('Error fetching recent posts:', error);
    return [];
  }

  return data || [];
}

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await getBlogPost(params.slug);

  if (!post) {
    notFound();
  }

  const recentPosts = await getRecentPosts(params.slug);

  return (
    <div className="pt-20">
      <section className="relative bg-gradient-to-br from-neutral-900 to-neutral-800 text-white py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/blog" className="inline-flex items-center text-amber-400 hover:text-amber-300 mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Blog
          </Link>
          <div className="inline-block bg-amber-700 text-white px-4 py-1 rounded-full text-sm font-medium mb-4">
            {post.category}
          </div>
          <h1 className="text-3xl md:text-5xl font-bold mb-6">{post.title}</h1>
          <div className="flex items-center gap-6 text-neutral-300">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              <span>{new Date(post.published_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="h-5 w-5" />
              <span>{post.author}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative h-96 rounded-lg overflow-hidden shadow-xl mb-12">
            <img
              src={post.image_url}
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-neutral-700 font-medium mb-8">{post.excerpt}</p>
            <div className="text-neutral-700 leading-relaxed whitespace-pre-line">
              {post.content}
            </div>
          </div>
        </div>
      </section>

      {recentPosts.length > 0 && (
        <section className="py-20 bg-neutral-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-neutral-900 mb-12 text-center">
              More Articles
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {recentPosts.map((relatedPost) => (
                <Link
                  key={relatedPost.id}
                  href={`/blog/${relatedPost.slug}`}
                  className="group"
                >
                  <div className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={relatedPost.image_url}
                        alt={relatedPost.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4 bg-amber-700 text-white px-3 py-1 rounded-full text-sm font-medium">
                        {relatedPost.category}
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-lg font-semibold text-neutral-900 group-hover:text-amber-700 transition-colors">
                        {relatedPost.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-20 bg-amber-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Inspired by What You've Read?
          </h2>
          <p className="text-xl text-amber-100 mb-8">
            Let's discuss how we can bring your custom woodworking vision to life.
          </p>
          <Button asChild size="lg" className="bg-white text-amber-700 hover:bg-neutral-100">
            <Link href="/contact">Schedule a Consultation</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
