import { Card, CardContent } from '@/components/ui/card';
import { Users, Award, Target, Heart } from 'lucide-react';
import path from 'path';
import fs from 'fs/promises';

export default async function AboutPage() {
  const dirPath = path.join(process.cwd(), 'public', 'zinoiMAGES')
  let imageFiles: string[] = []
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true })
    imageFiles = entries
      .filter((e) => e.isFile())
      .map((e) => e.name)
      .filter((n) => /\.(jpe?g|png|webp|gif)$/i.test(n))
  } catch {
    imageFiles = []
  }
  const toSrc = (name?: string) => (name ? `/zinoiMAGES/${encodeURIComponent(name)}` : '')
  const aboutImg1 = toSrc(imageFiles[2])
  const aboutImg2 = toSrc(imageFiles[3])
  const values = [
    {
      icon: Target,
      title: 'Precision',
      description: 'Every cut, joint, and finish is executed with meticulous attention to detail.',
    },
    {
      icon: Heart,
      title: 'Passion',
      description: 'We love what we do, and it shows in the quality of our craftsmanship.',
    },
    {
      icon: Users,
      title: 'Partnership',
      description: 'We work closely with clients to understand and exceed their expectations.',
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We never compromise on quality, using only the finest materials and techniques.',
    },
  ];

  const team = [
    {
      name: 'Marco Zino',
      role: 'Founder & Master Craftsman',
      image: toSrc(imageFiles[4]) || aboutImg1,
    },
    {
      name: 'Sarah Mitchell',
      role: 'Design Director',
      image: toSrc(imageFiles[5]) || aboutImg2 || aboutImg1,
    },
    {
      name: 'David Chen',
      role: 'Project Manager',
      image: toSrc(imageFiles[6]) || aboutImg1,
    },
    {
      name: 'Emily Rodriguez',
      role: 'Senior Carpenter',
      image: toSrc(imageFiles[7]) || aboutImg2 || aboutImg1,
    },
  ];

  return (
    <div className="pt-20">
      <section className="relative bg-gradient-to-br from-neutral-900 to-neutral-800 text-white py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About Zino Building Solutions</h1>
          <p className="text-xl text-neutral-200 max-w-3xl mx-auto">
            Bringing vision to life through exceptional woodworking and custom cabinetry since 2010.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-neutral-900">Our Story</h2>
              <p className="text-lg text-neutral-600 leading-relaxed">
                Founded in 2010 by master craftsman Marco Zino, Zino Building Solutions began as a small workshop in Toronto with a simple mission: to create exceptional custom woodwork that transforms spaces and exceeds expectations.
              </p>
              <p className="text-lg text-neutral-600 leading-relaxed">
                Over the years, we've grown into one of Canada's most trusted names in custom cabinetry and fine woodworking. Our team combines traditional craftsmanship with modern design principles, ensuring every project is both timeless and contemporary.
              </p>
              <p className="text-lg text-neutral-600 leading-relaxed">
                From elegant kitchen renovations to sophisticated office millwork, we've completed hundreds of projects across residential and commercial sectors, always maintaining our commitment to quality, precision, and client satisfaction.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="relative h-64 rounded-lg overflow-hidden shadow-lg">
                <img
                  src={aboutImg1}
                  alt="Workshop project"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="relative h-64 rounded-lg overflow-hidden shadow-lg mt-8">
                <img
                  src={aboutImg2 || aboutImg1}
                  alt="Project detail"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">Our Values</h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              The principles that guide everything we do at Zino Building Solutions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="border-neutral-200 text-center">
                <CardContent className="p-8 space-y-4">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
                    <value.icon className="h-8 w-8 text-amber-700" />
                  </div>
                  <h3 className="text-xl font-semibold text-neutral-900">{value.title}</h3>
                  <p className="text-neutral-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <h3 className="text-2xl font-bold text-neutral-900 mb-4">Who We Serve</h3>
              <ul className="space-y-2 text-neutral-700">
                <li>• Homeowners (consumers)</li>
                <li>• Construction companies and contractors</li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <h3 className="text-2xl font-bold text-neutral-900 mb-4">Services</h3>
              <ul className="space-y-2 text-neutral-700">
                <li>• Kitchen cabinetry and installation</li>
                <li>• Closet shelving and wardrobe systems</li>
                <li>• Laundry room cabinets</li>
                <li>• Bathroom vanities</li>
                <li>• Toilet partitions (commercial)</li>
                <li>• Manufacturing of cabinets and all wood shelving</li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <h3 className="text-2xl font-bold text-neutral-900 mb-4">Project Types</h3>
              <ul className="space-y-2 text-neutral-700">
                <li>• Residential</li>
                <li>• Commercial</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">Meet Our Team</h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              The skilled professionals behind every exceptional project.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="text-center group">
                <div className="relative h-64 rounded-lg overflow-hidden shadow-lg mb-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900">{member.name}</h3>
                <p className="text-amber-700 font-medium">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-amber-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12 text-center">
            <div>
              <div className="text-5xl font-bold mb-2">500+</div>
              <p className="text-xl text-amber-100">Projects Completed</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">13</div>
              <p className="text-xl text-amber-100">Years of Excellence</p>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">98%</div>
              <p className="text-xl text-amber-100">Client Satisfaction</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
